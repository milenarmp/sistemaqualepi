<div class="barraLateral">
	<div id="mySidenav" class="sidenav">
		<div class="usuarioBarra">
			<div class="iconeBarra">
			</div>
			<div class="nomeBarra">
			</div>
		</div>
		<div class="linkBarra">
            <a href="" class="closebtn" onclick="">&times;</a>
            <a href=""><span><img class="icones" src="../imagens/inicio.png"/></span> Área Inicial</a>
            <a href="notas.php"><span><img class="icones" src="../imagens/icone-notas.png"/></span> Favoritos</a>
            <a href="financeiro.php"><span><img class="icones" src="../imagens/cone-financeiro.png"/></span> Pesquisar EPIs</a>
            <a href=""><span><img class="icones" src="../imagens/icone-logout.png"/> Sair</span></a>
    	</div>
</div>