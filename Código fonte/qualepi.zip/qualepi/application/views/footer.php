
	</body>
	<footer>
		<div class="rodape">
      <div class="row">
			<ul class="nav col-lg-8 links">
  				<li class="nav-item">
    				<a class="nav-link barraRodape" href="/qualepi/index.php/EPIController/contato" >Contato</a>
  				</li>
  				<li class="nav-item">
    				<a class="nav-link barraRodape" href="http://trabalho.gov.br/">MTE</a>
  				</li>
  				<li class="nav-item">
    				<a class="nav-link barraRodapeUltimo" href="/qualepi/index.php/UsuarioController/cadastro">Cadastro</a>
  				</li>
			</ul>
      <div class="col-lg-4">
			<span class="navbar-text">Desenvolvido por Milena Rodrigues dos S. Pereira </span>
      <span class="navbar-text offset-md-4">Copyright 2019</span>
    </div>
    </div>
		</div>
	</footer>
	</div> <!-- div container -->