<script src="<?=base_url("assets/js/ManterEPI.js") ?>"></script>
<div class="cadastro">
	<div class="titulo">
		<h4>Manter EPIs</h4>
                <h3></h3>
	</div>
    <button type="button" class="btn btn-success" id="btnAtualizarEPIs">Atualizar EPIs</button>
</div>