<div class="cadastro">
	<div class="row">
		<div class="titulo">
			<h4>Contato</h4>
		</div>
	</div>
	<div class="row">
		<h5 class="titulo"> O Sistema QualEPI foi desenvolvido pela aluna do IFSP com a finalidade de Trabalho de Conclusão de Curso para o curso de Análise e DEsenvolvimento de Sistemas. A aluna pode ser contatada através do e-mail institucional: m.rodrigues@aluno.ifsp.edu.br </h5>
	</div>
</div>