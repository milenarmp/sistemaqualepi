<div class="cadastro">
	<div class="row">
		<div class="titulo">
			<h4>Sobre nós</h4>
		</div>
	</div>
	<div class="row">
		<h5 class="titulo"> O Sistema QualEPI foi desenvolvido com o objetivo de oferecer uma ferramenta que seja simples de usar e forneça informações sobre equipamentos de proteção individual até para quem não está familiarizado!</h5>
	</div>
</div>