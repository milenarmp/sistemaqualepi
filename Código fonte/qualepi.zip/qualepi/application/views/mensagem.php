<div class="cadastro">
	<div class="titulo">
		<h4><?=$mensagem['titulo']?></h4>
                <h3></h3>
	</div>
	<div class="row">
		<div class="col">
			<p><?=$mensagem['observacoes']?></p>
		</div>
	</div>
</div>